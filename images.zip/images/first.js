name= "tony sharma";
console.log("name");